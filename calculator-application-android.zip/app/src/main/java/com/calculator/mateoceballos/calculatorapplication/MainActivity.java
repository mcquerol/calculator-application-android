package com.calculator.mateoceballos.calculatorapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private Button btn_add,btn_subt,btn_mul,btn_div,btn_clr;
    private TextView txt_Total;
    private EditText txt_FirstNum, txt_SecNum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }
    private void init(){
        btn_add = (Button)findViewById(R.id.btn_add);
        btn_subt = (Button)findViewById(R.id.btn_subt);
        btn_mul = (Button)findViewById(R.id.btn_mul);
        btn_div = (Button)findViewById(R.id.btn_div);
        btn_clr = (Button)findViewById(R.id.btn_clr);
        txt_FirstNum = (EditText)findViewById(R.id.txt_FirstNum);
        txt_SecNum = (EditText)findViewById(R.id.txt_SecNum);
        txt_Total = (TextView)findViewById(R.id.txt_Total);


        btn_add.setOnClickListener(this);
        btn_subt.setOnClickListener(this);
        btn_mul.setOnClickListener(this);
        btn_div.setOnClickListener(this);
        btn_clr.setOnClickListener(this);
    }
    @Override
    public void onClick(View view) {
        String num1 = txt_FirstNum.getText().toString();
        String num2 = txt_SecNum.getText().toString();

        if(txt_FirstNum.getText().toString().equals("") || txt_SecNum.getText().toString().equals("")){
            txt_FirstNum.setText("0");
            txt_SecNum.setText("0");
            txt_Total.setText("0.0");
        }else{
            if(view.getId() == R.id.btn_add) {
                float addition = Float.parseFloat(num1) + Float.parseFloat(num2);
                txt_Total.setText(String.valueOf(addition));
            }else if(view.getId() == R.id.btn_subt){
                float subtraction = Float.parseFloat(num1) - Float.parseFloat(num2);
                txt_Total.setText(String.valueOf(subtraction));
            }else if(view.getId() == R.id.btn_mul){
                float multiplication = Float.parseFloat(num1) * Float.parseFloat(num2);
                txt_Total.setText(String.valueOf(multiplication));
            }else if(view.getId() == R.id.btn_div){
                try {
                    float division = Float.parseFloat(num1) / Float.parseFloat(num2);
                    txt_Total.setText(String.valueOf(division));
                }catch (Exception e){
                    txt_Total.setText("Cannot Divide!");
                }
            }
        }
        if(view.getId() == R.id.btn_clr){
            txt_FirstNum.setText("");
            txt_SecNum.setText("");
            txt_Total.setText("");
        }
    }
}